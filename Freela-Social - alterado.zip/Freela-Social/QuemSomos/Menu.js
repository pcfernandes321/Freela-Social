    // Carregar o conteúdo do cabeçalho
    fetch("Menu.html")
        .then(response => response.text())
        .then(content => {
            document.getElementById("Menu-placeholder").innerHTML = content;
        });

    const imageLoop = document.querySelector(".image-loop");

    // URLs das imagens
    const imageUrls = [
        "Imagens/lop1.jpg",
        "Imagens/lop2.jpg",
        "Imagens/lop3.jpg",
    ];

    // Adiciona as imagens ao elemento .image-loop
    imageUrls.forEach(function (imageUrl) {
        const img = document.createElement("img");
        img.src = imageUrl;
        imageLoop.appendChild(img);
    });
