
function validarFormulario() {
    var nome = document.getElementById("nome").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    if (nome === "" || email === "" || password === "") {
        alert("Por favor, preencha todos os campos obrigatórios.");
        return false; 
    }

    

    return true; 
}


var formulario = document.getElementById("cadastro-form");
formulario.addEventListener("submit", function (event) {
    if (!validarFormulario()) {
        event.preventDefault(); 
    } else {
        alert("Formulário enviado com sucesso!");  
    }
});
