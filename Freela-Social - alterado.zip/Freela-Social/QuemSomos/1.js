document.addEventListener("DOMContentLoaded", function() {
  const exemploElemento = document.querySelector(".exemplo-clique"); // Substitua pela classe ou ID apropriados

  if (exemploElemento) {
    exemploElemento.addEventListener("click", function() {
      alert("Você clicou no elemento de exemplo!");
    });
  }
});
